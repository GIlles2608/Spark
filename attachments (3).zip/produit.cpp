#include "produit.h"
#include <QString>
#include <QSqlQuery>
#include <QtDebug>
#include <QObject>

Produit::Produit()
{
ref=" ",intitule=" ",quantite=0,categorie=" ",prix=0;
}
Produit::Produit(QString ref,QString intitule,int quantite,QString categorie,int prix)
{this->ref=ref ;this->intitule=intitule ;this->quantite=quantite ;this->categorie=categorie ; this->prix=prix;}

QString Produit::getref(){return ref;}
 QString  Produit::getintitule(){return intitule;}
 int  Produit::getquantite(){return quantite;}
 QString  Produit::getcategorie(){return categorie;}
 int  Produit::getprix(){return prix;}
 void Produit::setref(QString ref){this->ref=ref ;}
 void Produit::setintitule(QString intitule){this->intitule=intitule ;}
 void Produit::setquantite(int quantite){this->quantite=quantite ;}
 void Produit::setcategorie(QString categorie ){this->categorie=categorie ;}
 void Produit::setprix(int prix){ this->prix=prix;}
bool Produit::ajouter()
{
    QSqlQuery query;
//QString ref_string= QString::ref;
         query.prepare("INSERT INTO PRODUIT (REF, INTITULE, QUANTITE, CATEGORIE,PRIX) "
                       "VALUES (:ref, :intitule, :quantite, :categorie, :prix)");
         query.bindValue(":ref", ref);
         query.bindValue(":intitule", intitule);
         query.bindValue(":quantite", quantite);
         query.bindValue(":categorie", categorie);
         query.bindValue(":prix", prix);
         return query.exec();


}
bool Produit::supprimer(QString ref)
{
    QSqlQuery query;
//QString ref_string= QString::ref;
         query.prepare(" Delete from PRODUIT where ref =:ref");
         query.bindValue(0, ref);

         return query.exec();

}
QSqlQueryModel* Produit::afficher()
{
   QSqlQueryModel* model=new QSqlQueryModel();
         model->setQuery("SELECT* FROM PRODUIT");
         model->setHeaderData(0, Qt::Horizontal, QObject::tr("ref"));
         model->setHeaderData(1, Qt::Horizontal, QObject::tr("intitule"));
         model->setHeaderData(2, Qt::Horizontal, QObject::tr("quantite"));
         model->setHeaderData(3, Qt::Horizontal, QObject::tr("categorie"));
          model->setHeaderData(3, Qt::Horizontal, QObject::tr("prix"));
         return model;
}


bool Produit :: modifier(QString ref)
{
     QSqlQuery query;



        //QString res= QString::getref;
        query.prepare("UPDATE PRODUIT SET ref=:ref,intitule=:intitule,quantite=:quantite ,categorie=:categorie ,prix=:prix WHERE ref=:ref");
        query.bindValue(":ref", ref);
        query.bindValue(":intitule", intitule);
        query.bindValue(":quantite", quantite);
        query.bindValue(":categorie", categorie);
        query.bindValue(":prix", prix);



           return    query.exec();

}
