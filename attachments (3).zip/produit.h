#ifndef PRODUIT_H
#define PRODUIT_H
#include <QString>
#include <QSqlQueryModel>

class Produit
{
public:
    Produit();
    Produit(QString,QString,int,QString,int);
    QString getref();
     QString getintitule();
     int getquantite();
     QString getcategorie();
     int getprix();
     void setref(QString);
     void setintitule(QString);
     void setquantite(int);
     void setcategorie(QString);
     void setprix(int);
    bool ajouter();
    QSqlQueryModel* afficher();
    bool supprimer(QString);
    bool modifier(QString ref);
private:
    QString ref;
    QString intitule;
    int quantite;
    QString categorie;
    int prix;
};

#endif // PRODUIT_H
