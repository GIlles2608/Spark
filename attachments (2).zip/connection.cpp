#include "connection.h"
#include "produit.h"
#include <QSqlDatabase>

Connection::Connection()
{

}

bool Connection::createconnect()
{bool test=false;
QSqlDatabase db = QSqlDatabase::addDatabase("QODBC");
db.setDatabaseName("test-bd");
db.setUserName("Raniia");//inserer nom de l'utilisateur
db.setPassword("121101");//inserer mot de passe de cet utilisateur

if (db.open())
test=true;





    return  test;
}

