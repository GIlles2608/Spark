#include "mainwindow.h"
#include "ui_mainwindow.h"
#include "produit.h"
#include <QIntValidator>
#include <QApplication>
#include <QMessageBox>
#include <QTableView>

MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow)
{
    ui->setupUi(this);
    ui->le_ref ->setValidator(new QIntValidator(0, 9999999, this));
    ui->tab_Produit->setModel( P1.afficher());
}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::on_Button_Ajouter_clicked()
{
    QString ref=ui->le_ref->text();
    QString intitule=ui->le_intitule->text();
    int quantite=ui->le_quantite->text().toInt();
    QString categorie=ui->le_categorie->text();
   int prix=ui->le_prix->text().toInt();
    Produit P(ref,intitule,quantite,categorie,prix);
    bool test=P.ajouter();


    if(test)
    {
        ui->tab_Produit->setModel(P1.afficher());
        QMessageBox::information(nullptr, QObject::tr("OK"),
                   QObject::tr("ajout effectue\n"
                               "click cancel te exit."), QMessageBox::Cancel);
    }
    else

        QMessageBox::critical(nullptr, QObject::tr("Not OK"),
                   QObject::tr("ajout non effectue\n"
                               "click cancel te exit."), QMessageBox::Cancel);

}

void MainWindow::on_ButtonSupprimer_clicked()
{
    Produit P2; P2.setref(ui->le_ref_sup->text());
    bool test=P2.supprimer(P2.getref());
    QMessageBox msgBox;

    if(test)
    {
        ui->tab_Produit->setModel(P1.afficher());
        msgBox.setText("suppression avec succes");
    }
    else
    msgBox.setText("echec de suppression");
    msgBox.exec();

}

void MainWindow::on_Button_Modification_clicked()
{
    QString ref=ui->le_ref_2->text();
    QString intitule=ui->le_intitule_2->text();
    int quantite=ui->le_quantite_2->text().toInt();
    QString categorie=ui->le_categorie_2->text();
    int prix=ui->le_prix_2->text().toInt();

    Produit c(ref, intitule, quantite, categorie,prix);
    bool test=c.modifier(ref);
    if(test)
    {

        ui->tab_Produit->setModel(c.afficher());//refresh

               QMessageBox::information(nullptr, QObject::tr("effectué"),
                    QObject::tr(" Modifié.\n"
                                "Click Cancel to exit."), QMessageBox::Cancel);
               ui->le_ref_2->clear();
               ui->le_intitule_2->clear();
               ui->le_quantite_2->clear();
               ui->le_categorie_2->clear();
                ui->le_prix_2->clear();
   }
    else
    {
        QMessageBox::critical(nullptr, QObject::tr("non effectué"),
                    QObject::tr("non modifié !.\n"
                                "Click Cancel to exit."), QMessageBox::Cancel);
        ui->le_ref_2->clear();
        ui->le_intitule_2->clear();
        ui->le_quantite_2->clear();
        ui->le_categorie_2->clear();
         ui->le_prix_2->clear();



    }

}
